// Fade in the body element on load
document.addEventListener('DOMContentLoaded', function() {
  const body = document.querySelector('body');
  body.style.opacity = '1';
});